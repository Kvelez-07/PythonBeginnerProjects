import pygame
import random

pygame.init()

# USER INPUT
gadget_pair = 1
option = int(input("Enter 1 for left gadget or 2 for right gadget: "))
match option:
    case 1:
        gadget_pair = 1
    case 2:
        gadget_pair = 2

# INITIAL VARIABLES
WIDTH, HEIGHT = 1050, 600  # dimensions of the window
wn = pygame.display.set_mode((WIDTH, HEIGHT))  # single-element tuple
pygame.display.set_caption("Pygame Pong")
run = True
player_1 = player_2 = 0 # scores
direction = [0, 1]
angle = [0, 1, 2]

# COLORS
BLUE = (0, 0, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# BALL VARIABLES
ball_radius = 15
ball_x, ball_y = WIDTH // 2 - ball_radius, HEIGHT // 2 - ball_radius
ball_vel_x, ball_vel_y = 0.25, 0.25
# dummy_ball variables
dummy_ball_x, dummy_ball_y = WIDTH // 2 - ball_radius, HEIGHT // 2 - ball_radius
dummy_ball_vel_x, dummy_ball_vel_y = 0.25, 0.25

# PADDLE VARIABLES
paddle_width, paddle_height = 20, 120

left_paddle_y = right_paddle_y = HEIGHT // 2 - paddle_height // 2

left_paddle_x = 100 - paddle_width // 2
right_paddle_x = WIDTH - 100 - paddle_width // 2  # Horizontal distance between paddles

second_left_paddle_y = second_right_paddle_y = HEIGHT // 2 - paddle_height // 2
second_left_paddle_x, second_right_paddle_x = 100 - paddle_width // 2, WIDTH - 100 - paddle_width // 2

right_paddle_vel = left_paddle_vel = 0
second_right_paddle_vel = second_left_paddle_vel = 0

# GADGETS
left_gadget = right_gadget = 0
left_gadget_remaining = right_gadget_remaining = 5

# GAME LOOP
while run:
    wn.fill(BLACK)  # fill the window with black

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                right_paddle_vel = -0.5
                second_right_paddle_vel = -0.5
            if event.key == pygame.K_DOWN:
                right_paddle_vel = 0.5
                second_right_paddle_vel = 0.5
            if event.key == pygame.K_RIGHT and right_gadget_remaining > 0:
                right_gadget = 1 # right_gadget = 1 means the gadget is on
            if event.key == pygame.K_LEFT and right_gadget_remaining > 0:
                right_gadget = 2
            if event.key == pygame.K_w:
                left_paddle_vel = -0.5
                second_left_paddle_vel = -0.5
            if event.key == pygame.K_s:
                left_paddle_vel = 0.5
                second_left_paddle_vel = 0.5
            if event.key == pygame.K_d and left_gadget_remaining > 0:
                left_gadget = 1 # left_gadget = 1 means the gadget is on
            if event.key == pygame.K_a and left_gadget_remaining > 0:
                left_gadget = 2

        if event.type == pygame.KEYUP:
            right_paddle_vel = 0
            second_right_paddle_vel = 0
            left_paddle_vel = 0
            second_left_paddle_vel = 0

    # Motion control (bouncing off the paddles)
    if ball_y <= 0 + ball_radius or ball_y >= HEIGHT - ball_radius:
        ball_vel_y *= -1

    # Dummy ball motion
    if dummy_ball_y <= 0 + ball_radius or dummy_ball_y >= HEIGHT - ball_radius:
        dummy_ball_vel_y *= -1

    # Retrieve initial ball position
    if ball_x >= WIDTH - ball_radius:
        player_1 += 1  # increment player_1 score
        ball_x, ball_y = WIDTH // 2 - ball_radius, HEIGHT // 2 - ball_radius
        dummy_ball_x, dummy_ball_y = WIDTH // 2 - ball_radius, HEIGHT // 2 - ball_radius
        second_left_paddle_y = left_paddle_y
        second_right_paddle_y = right_paddle_y
        dir = random.choice(direction)
        ang = random.choice(angle)

        if dir == 0:
            if ang == 0:
                ball_vel_x, ball_vel_y = -0.7, 0.15
                dummy_ball_vel_x, dummy_ball_vel_y = -0.7, 0.15
            if ang == 1:
                ball_vel_y, ball_vel_x = -0.15, 0.15
                dummy_ball_vel_y, dummy_ball_vel_x = -0.15, 0.15
            if ang == 2:
                ball_vel_x, ball_vel_y = -0.15, 0.7
                dummy_ball_vel_x, dummy_ball_vel_y = -0.15, 0.7

        if dir == 1:
            if ang == 0:
                ball_vel_x, ball_vel_y = 0.7, 0.15
                dummy_ball_vel_x, dummy_ball_vel_y = 0.7, 0.15
            if ang == 1:
                ball_vel_y, ball_vel_x = 0.15, 0.15
                dummy_ball_vel_y, dummy_ball_vel_x = 0.15, 0.15
            if ang == 2:
                ball_vel_x, ball_vel_y = 0.15, 0.7
                dummy_ball_vel_x, dummy_ball_vel_y = 0.15, 0.7

        ball_vel_x *= -1
        dummy_ball_vel_x *= -1

    # Retrieve initial ball position
    if ball_x <= 0 + ball_radius:
        player_2 += 1  # increment player_2 score
        ball_x, ball_y = WIDTH // 2 - ball_radius, HEIGHT // 2 - ball_radius
        dummy_ball_x, dummy_ball_y = WIDTH // 2 - ball_radius, HEIGHT // 2 - ball_radius
        second_left_paddle_y = left_paddle_y
        second_right_paddle_y = right_paddle_y
        dir = random.choice(direction)
        ang = random.choice(angle)

        if dir == 0:
            if ang == 0:
                ball_vel_x, ball_vel_y = -0.7, 0.15
                dummy_ball_vel_x, dummy_ball_vel_y = -0.7, 0.15
            if ang == 1:
                ball_vel_y, ball_vel_x = -0.15, 0.15
                dummy_ball_vel_y, dummy_ball_vel_x = -0.15, 0.15
            if ang == 2:
                ball_vel_x, ball_vel_y = -0.15, 0.7
                dummy_ball_vel_x, dummy_ball_vel_y = -0.15, 0.7

        if dir == 1:
            if ang == 0:
                ball_vel_x, ball_vel_y = 0.7, 0.15
                dummy_ball_vel_x, dummy_ball_vel_y = 0.7, 0.15
            if ang == 1:
                ball_vel_y, ball_vel_x = 0.15, 0.15
                dummy_ball_vel_y, dummy_ball_vel_x = 0.15, 0.15
            if ang == 2:
                ball_vel_x, ball_vel_y = 0.15, 0.7
                dummy_ball_vel_x, dummy_ball_vel_y = 0.15, 0.7

        ball_vel_x *= -1
        dummy_ball_vel_x *= -1

    # Paddle motion control
    if left_paddle_y >= HEIGHT - paddle_height:
        left_paddle_y = HEIGHT - paddle_height
    if left_paddle_y <= 0:
        left_paddle_y = 0
    if right_paddle_y >= HEIGHT - paddle_height:
        right_paddle_y = HEIGHT - paddle_height
    if right_paddle_y <= 0:
        right_paddle_y = 0

    if second_left_paddle_y >= HEIGHT - paddle_height:
        second_left_paddle_y = HEIGHT - paddle_height
    if second_left_paddle_y <= 0:
        second_left_paddle_y = 0
    if second_right_paddle_y >= HEIGHT - paddle_height:
        second_right_paddle_y = HEIGHT - paddle_height
    if second_right_paddle_y <= 0:
        second_right_paddle_y = 0

    # Collision detection
    # left paddle
    if second_left_paddle_y == left_paddle_y:
        if left_paddle_x <= ball_x <= left_paddle_x + paddle_width:
            if left_paddle_y <= ball_y <= left_paddle_y + paddle_height:
                ball_x = left_paddle_x + paddle_width
                dummy_ball_x = left_paddle_x + paddle_width
                ball_vel_x *= -1
                dummy_ball_vel_x *= -1

    if second_left_paddle_y != left_paddle_y:
        if left_paddle_x <= ball_x <= left_paddle_x + paddle_width:
            if left_paddle_y <= ball_y <= left_paddle_y + paddle_height:
                ball_x = left_paddle_x + paddle_width
                dummy_ball_x = left_paddle_x + paddle_width
                ball_vel_x *= -1
                dummy_ball_vel_x *= -1

        if second_left_paddle_x <= ball_x <= second_left_paddle_x + paddle_width:
            if second_left_paddle_y <= ball_y <= second_left_paddle_y + paddle_height:
                ball_x = second_left_paddle_x + paddle_width
                dummy_ball_x = second_left_paddle_x + paddle_width
                ball_vel_x *= -1
                dummy_ball_vel_x *= -1

    # right paddle
    if second_right_paddle_y == right_paddle_y:
        if right_paddle_x <= ball_x <= right_paddle_x + paddle_width:
            if right_paddle_y <= ball_y <= right_paddle_y + paddle_height:
                ball_x = right_paddle_x - ball_radius
                dummy_ball_x = right_paddle_x - ball_radius
                ball_vel_x *= -1
                dummy_ball_vel_x *= -1

    if second_right_paddle_y != right_paddle_y:
        if right_paddle_x <= ball_x <= right_paddle_x + paddle_width:
            if right_paddle_y <= ball_y <= right_paddle_y + paddle_height:
                ball_x = right_paddle_x - ball_radius
                dummy_ball_x = right_paddle_x - ball_radius
                ball_vel_x *= -1
                dummy_ball_vel_x *= -1

        if second_right_paddle_x <= ball_x <= second_right_paddle_x + paddle_width:
            if second_right_paddle_y <= ball_y <= second_right_paddle_y + paddle_height:
                ball_x = second_right_paddle_x - ball_radius
                dummy_ball_x = second_right_paddle_x - ball_radius
                ball_vel_x *= -1
                dummy_ball_vel_x *= -1

    # gadget actions
    if gadget_pair == 1:
        if left_gadget == 1:
            if left_paddle_x <= ball_x <= left_paddle_x + paddle_width:
                if left_paddle_y <= ball_y <= left_paddle_y + paddle_height:
                    ball_x = left_paddle_x + paddle_width
                    ball_vel_x *= -3.5
                    dummy_ball_vel_x *= -3.5
                    left_gadget = 0 # left_gadget = 0 means the gadget is off
                    left_gadget_remaining -= 1 # decrement the number of remaining gadgets
        elif left_gadget == 2:
            left_paddle_y = ball_y
            left_gadget = 0
            left_gadget_remaining -= 1

        elif right_gadget == 2:
            second_left_paddle_y = left_paddle_y + 200
            left_gadget = 0
            left_gadget_remaining -= 1

        if right_gadget == 1:
            if right_paddle_x <= ball_x <= right_paddle_x + paddle_width:
                if right_paddle_y <= ball_y <= right_paddle_y + paddle_height:
                    ball_x = right_paddle_x - ball_radius
                    ball_vel_x *= -3.5
                    dummy_ball_vel_x *= -3.5
                    right_gadget = 0 # right_gadget = 0 means the gadget is off
                    right_gadget_remaining -= 1 # decrement the number of remaining gadgets
        elif right_gadget == 2:
            right_paddle_y = ball_y
            right_gadget = 0
            right_gadget_remaining -= 1
        
    if gadget_pair == 2:
        if left_gadget == 1:
            if left_paddle_x <= ball_x <= left_paddle_x + paddle_width:
                if left_paddle_y <= ball_y <= left_paddle_y + paddle_height:
                    ball_x = left_paddle_x + paddle_width
                    dummy_ball_x = left_paddle_x + paddle_width
                    ball_vel_x *= -1
                    dummy_ball_vel_x *= -1
                    dummy_ball_vel_y *= -1
                    left_gadget = 0
                    left_gadget_remaining -= 1

        if right_gadget == 1:
            if right_paddle_x <= ball_x <= right_paddle_x + paddle_width:
                if right_paddle_y <= ball_y <= right_paddle_y + paddle_height:
                    ball_x = right_paddle_x - ball_radius
                    dummy_ball_x = right_paddle_x - ball_radius
                    ball_vel_x *= -1
                    dummy_ball_vel_x *= -1
                    right_gadget = 0
                    right_gadget_remaining -= 1

        elif right_gadget == 2:
            second_right_paddle_y = right_paddle_y + 200
            right_gadget = 0
            right_gadget_remaining -= 1

    # Motion
    ball_x += ball_vel_x
    ball_y += ball_vel_y

    # Dummy ball
    dummy_ball_x += dummy_ball_vel_x
    dummy_ball_y += dummy_ball_vel_y

    # Paddle motion
    right_paddle_y += right_paddle_vel
    left_paddle_y += left_paddle_vel
    second_left_paddle_y += second_left_paddle_vel
    second_right_paddle_y += second_right_paddle_vel

    # Scoreboard
    font = pygame.font.SysFont('Comic Sans MS', 30)
    score_1 = font.render(f'Player 1: {player_1}', True, WHITE)
    wn.blit(score_1, (15, 15))
    score_2 = font.render(f'Player 2: {player_2}', True, WHITE)
    wn.blit(score_2, (825, 15))  # Adjusted position for Player 2 scoreboard label
    gad_left_1 = font.render(f'Left Gadget: {left_gadget_remaining}', True, WHITE)
    wn.blit(gad_left_1, (15, 50))
    gad_right_1 = font.render(f'Right Gadget: {right_gadget_remaining}', True, WHITE)
    wn.blit(gad_right_1, (825, 50))  # Adjusted position for Right Gadget label

    # OBJECTS
    # Draw the ball
    pygame.draw.circle(wn, BLUE, (ball_x, ball_y), ball_radius)

    # Draw the paddles
    pygame.draw.rect(wn, RED, pygame.Rect(left_paddle_x, left_paddle_y, paddle_width, paddle_height))
    pygame.draw.rect(wn, RED, pygame.Rect(right_paddle_x, right_paddle_y, paddle_width, paddle_height))

    # Draw the dummy ball
    pygame.draw.circle(wn, BLUE, (dummy_ball_x, dummy_ball_y), ball_radius)

    # Draw the second paddles
    pygame.draw.rect(wn, RED, pygame.Rect(second_left_paddle_x, second_left_paddle_y, paddle_width, paddle_height))
    pygame.draw.rect(wn, RED, pygame.Rect(second_right_paddle_x, second_right_paddle_y, paddle_width, paddle_height))

    # Gadget check
    if left_gadget == 1:
        pygame.draw.circle(wn, WHITE, (left_paddle_x + 10, left_paddle_y + 10), 4)

    if right_gadget == 1:
        pygame.draw.circle(wn, WHITE, (right_paddle_x + 10, right_paddle_y + 10), 4)

    # GAME OVER
    winning_font = pygame.font.SysFont('Comic Sans MS', 100)
    if player_1 == 3:
        wn.fill(BLACK)
        text = winning_font.render('Player 1 Wins!', True, WHITE)
        wn.blit(text, (350, 300))
    elif player_2 == 3:
        wn.fill(BLACK)
        text = winning_font.render('Player 2 Wins!', True, WHITE)
        wn.blit(text, (350, 300))

    # Update the display
    pygame.display.update()

pygame.quit()
