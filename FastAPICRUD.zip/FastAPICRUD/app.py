from datetime import datetime
from typing import Text, Optional, List
from fastapi import FastAPI, HTTPException
from fastapi import Body
from pydantic import BaseModel, Field
from uuid import uuid4, UUID

class Post(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    title: str
    author: str
    content: Text
    created_at: datetime = Field(default_factory=datetime.now)
    published_at: Optional[datetime] = None
    published: bool = False

# Use a dictionary for in-memory database
posts_db: List[Post] = []

app = FastAPI()

@app.get("/")
async def main():
    return {"message": "Hello World"}

@app.get("/posts/{post_id}", response_model=Post)
async def get_post(post_id: UUID):
    for post in posts_db:
        if post.id == post_id:
            return post
    raise HTTPException(status_code=404, detail="Post not found")

@app.get("/posts", response_model=List[Post])
async def get_posts():
    return posts_db

@app.post("/posts", response_model=Post, tags=["posts"])
async def create_post(post: Post = Body(...)):
    posts_db.append(post)
    return post

@app.put("/posts/{post_id}", response_model=Post, tags=["posts"])
async def update_post(post_id: UUID, updated_post: Post = Body(...)):
    for index, post in enumerate(posts_db):
        if post.id == post_id:
            updated_post.id = post_id  # Ensure the ID remains the same
            posts_db[index] = updated_post
            return updated_post
    raise HTTPException(status_code=404, detail="Post not found")

@app.delete("/posts/{post_id}", response_model=Post, tags=["posts"])
async def delete_post(post_id: UUID):
    for index, post in enumerate(posts_db):
        if post.id == post_id:
            deleted_post = posts_db.pop(index)
            return deleted_post
    raise HTTPException(status_code=404, detail="Post not found")
