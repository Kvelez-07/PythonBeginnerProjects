#!/bin/bash

sudo apt upgrade